﻿namespace WebApp.Models
{
    using AutoMapper;
    public class MapProfile : Profile
    {
        public MapProfile()
        {

        }
    }
}
